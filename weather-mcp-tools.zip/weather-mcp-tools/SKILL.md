---
name: weather-mcp-tools
description: Use when the user asks about US weather alerts, warnings, or forecasts. Routes the request to the weather MCP connector's get_alerts/get_forecast tools with correctly formatted arguments (state codes, lat/long).
---

# Weather MCP tools

Guidance for using the **weather** MCP connector (added via Settings →
Connectors, pointed at the deployed `weather.py` server) correctly.

## When to use this skill

- The user asks about active weather alerts/warnings for a US state.
- The user asks for a forecast at a specific location.
- The user wants a plain-language summary of weather risk (e.g. for travel
  or outdoor work).

Not applicable outside the US — the underlying data source is the National
Weather Service, which only covers US states and territories.

## Tools available on the connector

- **`get_alerts(state)`** — `state` must be the two-letter USPS code (e.g.
  `"CA"`, `"NY"`, `"TX"`), not a full state name. If the user names a state
  by its full name or mentions a city, convert to the correct two-letter
  code yourself before calling.
- **`get_forecast(latitude, longitude)`** — needs decimal latitude/longitude,
  not a city name or ZIP code. If the user gives a place name instead of
  coordinates, resolve it to approximate coordinates yourself (or ask the
  user) before calling — don't pass a place name into these parameters.

## Resource

- **`weather://alerts/{state}`** — the same alert data as `get_alerts`, but
  addressable as a resource. Prefer this over the tool only if the user
  wants to attach it as standing context rather than triggering a one-off
  lookup.

## Prompt

- **`weather_briefing(state)`** — a preset prompt template the connector
  exposes for generating a travel/outdoor-work risk summary. Use this
  framing when the user asks for a "briefing" rather than raw alert data.

## Response notes

- Both tools return plain formatted text, not JSON — summarize or quote it
  directly; don't attempt to parse it as structured data.
- `"Unable to fetch alerts or no alerts found."` and
  `"No active alerts for this state."` are normal, valid answers, not
  errors — don't retry the call when you see them.
- `get_forecast` only returns the next 5 forecast periods (day/night
  blocks), not raw hourly data — say so if the user asks for anything
  further out.
